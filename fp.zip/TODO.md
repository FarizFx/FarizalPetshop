# TODO: Persiapkan Folder Website untuk Upload ke cPanel

## Langkah 1: Update config.php ✅
- Tambahkan komentar di config.php untuk mengatur pengaturan database cPanel (host, user, password, database name).

## Langkah 2: Buat File ZIP ✅
- Buat file zip dari seluruh folder proyek (exclude .git jika ada) untuk upload mudah ke cPanel.

## Langkah 3: Update README.md ✅
- Tambahkan bagian instruksi deployment ke cPanel di README.md, termasuk setup database dan upload file.

## Langkah 4: Update config.php dengan komentar ✅
- Tambahkan komentar di config.php untuk panduan pengaturan cPanel.

## Langkah 5: Perbaiki database.sql ✅
- Hapus baris yang menyebabkan error import di cPanel.

## Langkah 6: Tambahkan user admin default ✅
- Tambahkan data user admin default ke database.sql.
